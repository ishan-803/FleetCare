const { body } = require('express-validator');

exports.validateSchedule = [
  body('vehicleId')
    .isString().withMessage('Vehicle ID must be a string') 
    .matches(/^V\d{3}$/).withMessage('Vehicle ID must be in the format V001'),
  body('technicianId')
    .isString().withMessage('Technician ID must be a string') 
    .matches(/^T\d{3}$/).withMessage('Technician ID must be in the format T001'),

  body('dueServiceDate')
    .isISO8601().withMessage('Due Service Date must be a valid ISO date')
    .custom((value) => {
      const inputDate = new Date(value);
      const today = new Date();
      if (inputDate <= today) {
        throw new Error('Due Service Date must be in the future');
      }
      return true;
    }),

  body('serviceType')
    .optional()
    .isString().withMessage('Service Type must be a string')
    .isIn(['Oil Change', 'Brake Repair', 'Battery Test'])
    .withMessage('Unsupported service type')
];